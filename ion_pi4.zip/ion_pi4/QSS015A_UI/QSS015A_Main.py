import os
import sys
sys.path.append('../')
import time
import logging
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
import py3lib.QuLogger as Qlogger
import py3lib.FileToArray as fil2a
import QSS015A_Widget as UI
import QSS015A_Action as ACT
import numpy as np
import datetime

import scipy as sp 

from scipy.ndimage import gaussian_filter1d  



monitor_width = 1000
monitor_height = 560

MAIN_W = int(monitor_width*0.8)
MAIN_H = int(monitor_height*0.8)


#Preset File Setting
IDX_IP = 0
IDX_HV_START = 1
IDX_HV_STEP = 2
IDX_HV_LOOPS = 3
IDX_HV_BKPTS = 4
IDX_HV_OFFSET = 5
IDX_ADC_LOOPS = 6
IDX_HV_DELAY = 7
IDX_HV_RESULT = 8

IDX_DC_FIX = 9
IDX_DC_ESI = 10
IDX_DC_FAN = 11
IDX_ADC_CH = 12
IDX_ADC_PO = 13
IDX_ADC_AVG = 14
IDX_ADC_TIMES = 15
IDX_MASS_CENTER = 16
IDX_MASS_RANGE = 17
IDX_THRESHOLD = 18
IDX_WIDTH = 19

GAUSSIAN_SIGMA = 20
MAX_IDX = 21


ESI_CHANNEL = 3
FAN_CHANNEL = 4

SETTING_FILEPATH = "set"
PRESET_FILE_NAME = "set/setting.txt"
READOUT_FILENAME = "Signal_Read_Out.txt"
ANALYSIS_FILENAME = "Data_Analysis.txt"

TITLE_TEXT = " iAnalyzer Inc. Ion Mobility Spectrometer "
VERSION_TEXT = TITLE_TEXT + "\n" + \
" iAnalyzer V1.061 \n\n" + \
" Copyright @ 2023 iAnalyzer Inc. \n" + \
" Maintain by iAnalyzer "

class scanParam():
        def __init__(self):
                self.loggername = "Total"
                self.ip = "hostname"

                self.start = 1000
                self.step = 200
                self.loops = 1
                self.scanBkWd = 0
                self.offset = 0
                self.max_run_loops = 1
                self.delay = 100
                self.autoShowResult = 1

                self.dc_fixed = 0
                self.dc_esi = 0
                self.dc_fan = 0

                self.channel_str = '0 '
                self.adc_pority = 1
                self.mv_avg_num = 50
                self.avg_time = 1

                self.xic_center = 100
                self.xic_delta = 1
                self.ana_height = 0
                self.ana_width = 1

                self.xicMode = False
                self.cutFreq = 0.7
                self.gaussian_sigma = 1

        def loadPresetFile(self):
                if not os.path.isdir(SETTING_FILEPATH):
                        os.mkdir(SETTING_FILEPATH)
                        self.savePresetFile()
                elif not os.path.exists(PRESET_FILE_NAME):
                        self.savePresetFile()
                else:
                        data = fil2a.TexTFileto1DList(PRESET_FILE_NAME,self.loggername)
                        
                        if (len(data) != MAX_IDX):
                                self.savePresetFile()
                        else:
                                self.ip = data[IDX_IP]

                                self.start = int(data[IDX_HV_START])
                                self.step = float(data[IDX_HV_STEP])
                                self.loops = int(data[IDX_HV_LOOPS])
                                self.scanBkWd = int(data[IDX_HV_BKPTS])
                                self.offset = int(data[IDX_HV_OFFSET])
                                self.max_run_loops = int(data[IDX_ADC_LOOPS])
                                self.delay = int(data[IDX_HV_DELAY])
                                self.autoShowResult = int(data[IDX_HV_RESULT])

                                self.dc_fixed = int(data[IDX_DC_FIX])
                                self.dc_esi = int(data[IDX_DC_ESI])
                                self.dc_fan = int(data[IDX_DC_FAN])

                                self.channel_str = data[IDX_ADC_CH]
                                self.adc_pority = int(data[IDX_ADC_PO])
                                self.mv_avg_num = int(data[IDX_ADC_AVG])
                                self.avg_time = int(data[IDX_ADC_TIMES])

                                self.xic_center = int(data[IDX_MASS_CENTER])
                                self.xic_delta = float(data[IDX_MASS_RANGE])
                                self.ana_height = int(data[IDX_THRESHOLD])
                                self.ana_width = int(data[IDX_WIDTH])
                                self.gaussian_sigma = int(data[GAUSSIAN_SIGMA])   
                                   
                                                  

        def savePresetFile(self):
                data = [0]*MAX_IDX
                data[IDX_IP] = self.ip

                data[IDX_HV_START] = self.start
                data[IDX_HV_STEP] = self.step
                data[IDX_HV_LOOPS] = self.loops
                data[IDX_HV_BKPTS] = self.scanBkWd
                data[IDX_HV_OFFSET] = self.offset
                data[IDX_ADC_LOOPS] = self.max_run_loops
                data[IDX_HV_DELAY] = self.delay
                data[IDX_HV_RESULT] = self.autoShowResult

                data[IDX_DC_FIX] = self.dc_fixed
                data[IDX_DC_ESI] = self.dc_esi
                data[IDX_DC_FAN] = self.dc_fan

                data[IDX_ADC_CH] = self.channel_str
                data[IDX_ADC_PO] = self.adc_pority
                data[IDX_ADC_AVG] = self.mv_avg_num
                data[IDX_ADC_TIMES] = self.avg_time

                data[IDX_MASS_CENTER] = self.xic_center
                data[IDX_MASS_RANGE] = self.xic_delta
                data[IDX_THRESHOLD] = self.ana_height
                data[IDX_WIDTH] = self.ana_width
                data[GAUSSIAN_SIGMA] = self.gaussian_sigma

                


                fil2a.array1DtoTextFile(PRESET_FILE_NAME, data, self.loggername)

class mainWindow(QMainWindow):
        def __init__(self, parent = None):
                super (mainWindow, self).__init__(parent)
                self.setWindowTitle(TITLE_TEXT)
                self.resize(MAIN_W, MAIN_H)
                self.move(50,50)
                self.loggername = "Total"
                self.addAccesoryFlag(self.loggername) # Add logger
                self.act = ACT.QSS015ction(self.loggername)
                self.fanact = ACT.QSS015ction2(self.act.COM, self.loggername)
                self.top = UI.mainWidget()
                self.setting = UI.Setting()
                self.setting.setMinimumSize(800, 450)
                #self.top.setMinimumSize(TOP_W, TOP_H)
                self.thread1 = QThread()
                self.thread2 = QThread()
                self.act.moveToThread(self.thread1)
                self.fanact.moveToThread(self.thread2)
                self.thread1.started.connect(lambda:self.act.VoltageOut(self.scanFlag,self.scanParam))
                self.thread2.started.connect(self.fanact.fanQuerry)
                self.act.update_text.connect(self.updateText)
                # self.act.update_array.connect(self.PlotData)
                self.act.update_array_filter.connect(self.PlotData)
                
                self.act.update_index.connect(self.UpdateAccuIndex)
                self.act.finished.connect(self.CloseThread)
                self.act.interLockError.connect(lambda:self.showErrorMsg(True, self.act.status))
                self.act.showErrorBox.connect(lambda:self.showErrorMsg(False, self.act.status))
                self.fanact.update_fan.connect(self.updateFan)
                self.fanact.finished.connect(self.CloseThread2)
                self.fanact.interLockError.connect(lambda:self.showErrorMsg(True, self.fanact.status))
                self.fanact.showErrorBox.connect(lambda:self.showErrorMsg(False, self.fanact.status))
                

                self.mainUI()
#                 self.mainMenu()
                self.mainInit()
                self.linkFunction()

        def mainUI(self):
                mainLayout = QGridLayout()
                #self.scorollerarea = QScrollArea()
                #self.scorollerarea.setWidget(self.top)
                self.setCentralWidget(QWidget(self))
                mainLayout.addWidget(self.top)
                self.centralWidget().setLayout(mainLayout)
        
#         def mainMenu(self):
#                 mainMenu = self.menuBar()
#                 menu_about = QAction("&Version", self)
#                 menu_about.triggered.connect(self.aboutBox)
#                 aboutMenu = mainMenu.addMenu("&About")
#                 aboutMenu.addAction(menu_about)

        def mainInit(self):
                self.ConnectRun()
                self.scanFlag = False
                self.scanParam = scanParam()
                self.scanParam.loadPresetFile()
                self.LoadPreset()
                self.preFanFlag = False
                self.InterLockStatus = 1
                self.tabIndex = 0
  
                self.ana_x = ''
                self.ana_y = ''
                self.x_data = ''
                self.accu_data = ''
                self.x1=''
                self.x2=''

                self.gaussian_filter=''
                self.showAnaResult=True
                self.r = self.setting.tabAll.DataText.anaRange.value()  
                self.DrawAnaPlot()

        def addAccesoryFlag(self, loggername):
                self.logger = logging.getLogger(loggername)
                #Qlogger.QuConsolelogger(loggername, logging.ERROR)
                Qlogger.QuFilelogger(loggername, logging.ERROR, "log.txt")

        def linkFunction(self):
                self.setting.tabAll.Signal_new.comport.btn.clicked.connect(self.ConnectRun)
                # self.setting.tabAll.DCset.V1_Btn.clicked.connect(self.setFixedVolt)
                self.setting.tabAll.DCset.V2_Btn.clicked.connect(self.setESI)  
                self.setting.tabAll.Fan.FanBtn.clicked.connect(self.setFan)
                #-----------------------------------------------------------------------------
                self.setting.tabAll.Fan.esiFanBtn.clicked.connect(self.setESIandFan)
                #-----------------------------------------------------------------------------
                self.setting.tabAll.HVscan.turnoff.clicked.connect(self.SetAllDacZero)

                self.setting.tabAll.Analysis.LoadBtn.clicked.connect(self.LoadAnaData)
                self.setting.tabAll.Analysis.CurrBtn.clicked.connect(self.UseCurrData)
                self.setting.tabAll.Analysis.AnaBtn.clicked.connect(self.FinkPeakBtn)
                self.setting.tabAll.Analysis.SaveBtn.clicked.connect(self.SaveAnaData)
                self.setting.tabAll.Analysis.Threshold.spin.valueChanged.connect(self.ShowThreshold)
                self.setting.tabAll.Analysis.Width.spin.valueChanged.connect(self.NoiseChange)
                #self.top.resetBtn.clicked.connect(self.resetBtn)
                self.setting.tabAll.Signal_new.DCmode.clicked.connect(self.DCmodeBtn)
                self.setting.tabAll.Signal_new.startScan.clicked.connect(self.ScanBtn)
                self.setting.tabAll.Signal_new.stop.clicked.connect(self.StopBtn)
                
                
                self.top.tabPlot.tabBarClicked.connect(self.onTabChange)

                self.top.tabPlot.plot1.startScan.clicked.connect((self.ScanBtn))
                self.top.tabPlot.plot1.stop.clicked.connect(self.StopBtn)
                self.top.tabPlot.plot1.setting.clicked.connect(self.SettingBtn)                
                self.top.tabPlot.plot1.anaResult.clicked.connect(self.anaResult)                
                self.top.tabPlot.plot1.anaResult1.clicked.connect(self.anaResult1)                
                self.top.tabPlot.plot1.closeBtn.clicked.connect(self.onClosePress)

                # self.top.tabPlot.plot3.startScan.clicked.connect((self.ScanBtn))
                # self.top.tabPlot.plot3.stop.clicked.connect(self.StopBtn)
                
                self.top.tabPlot.plot3.LoadBtn.clicked.connect(self.LoadAnaData)  
                self.top.tabPlot.plot3.setting.clicked.connect(self.SettingBtn)                
                self.top.tabPlot.plot3.anaResult.clicked.connect(self.anaResult)                
                self.top.tabPlot.plot3.anaResult1.clicked.connect(self.anaResult1)                
                self.top.tabPlot.plot3.closeBtn.clicked.connect(self.onClosePress)


                self.setting.tabAll.Signal_new.Signal.SaveDataBtn.clicked.connect(self.SaveAvgData)
                #-----------------------------------------------------------------------------
                self.setting.tabAll.DataText.TextBtn.clicked.connect(self.TextBtnData)

                
                self.setting.tabAll.DataText.anaRange.textChanged.connect(self.onChangeValue)
                self.setting.tabAll.DataText.TextBtn.clicked.connect(self.TextBtnData)
                for i in range(8):
                        getattr(self.setting.tabAll.DataText,f'v{i+1}').textChanged.connect(self.onChangeValue)
                        getattr(self.setting.tabAll.DataText,f'n{i+1}').textChanged.connect(self.onChangeValue)
                        getattr(self.setting.tabAll.DataText,f'x{i+1}').textChanged.connect(self.onChangeValue)
                        getattr(self.setting.tabAll.DataText,f'y{i+1}').textChanged.connect(self.onChangeValue)
                        getattr(self.setting.tabAll.DataText,f'c{i+1}').currentTextChanged.connect(self.onChangeValue)
   


        def onChangeValue(self):
                self.TextBtnData()
                self.r=self.setting.tabAll.DataText.anaRange.value()  

                self.top.tabPlot.plot1.ax2.clear()                
                self.top.tabPlot.plot3.ax.clear()
                
                self.top.tabPlot.plot1.ax2.set_yticks([110])
                self.top.tabPlot.plot1.ax2.set_xticks([0])  

                x1=self.setting.tabAll.HVscan.StartVoltage.value()-self.setting.tabAll.DCset.DC_Voltage1.value()

                # print(self.top.tabAll.HVscan.StartVoltage.spin.value(),self.top.tabAll.DCset.DC_Voltage1.spin.value(),x1)

                x2=x1+self.setting.tabAll.HVscan.Loop.value()

                # print(self.top.tabAll.HVscan.Loop.spin.value(),x2)
                
                self.top.tabPlot.plot1.ax2.set(xlim=(x1,x2),ylim=(0,100))  
                self.top.tabPlot.plot1.ax1.set(xlim=(x1,x2)) 

                if len(self.ana_x) != 0:
                        self.DrawAnaPlot() 

                
                for j in range(8):
                        v = getattr(self.setting.tabAll.DataText,f'v{j+1}').value()  
                        n = getattr(self.setting.tabAll.DataText,f'n{j+1}').text()  
                        x = getattr(self.setting.tabAll.DataText,f'x{j+1}').value()  
                        y = getattr(self.setting.tabAll.DataText,f'y{j+1}').value()  
                        c = getattr(self.setting.tabAll.DataText,f'c{j+1}').currentText() 
                        
                        if (int(v) != 0 ):
                                self.top.tabPlot.plot1.ax2.bar([int(v)],[100],width=self.r*2,alpha=.1,color=str(c))   
                                self.top.tabPlot.plot1.ax2.text(int(x),int(y),str(n),fontsize=14,fontfamily='SimSun')  

                                if len(self.ana_x) == 0:
                                        self.top.tabPlot.plot3.ax.set(xlim=(50,200),ylim=(0,100))  
                                        text_y=100
                                        self.top.tabPlot.plot3.ax.bar([int(v)],[text_y],width=self.r*2,alpha=.1,color=str(c))   
                                        self.top.tabPlot.plot3.ax.text(int(x),text_y*int(y)/100+text_y/20,str(n),fontsize=14,fontfamily='SimSun')  

                                
                self.top.tabPlot.plot1.figure.canvas.draw()
                self.top.tabPlot.plot1.figure.canvas.flush_events()
                
                self.top.tabPlot.plot3.figure.canvas.draw()     
                self.top.tabPlot.plot3.figure.canvas.flush_events()

                
                
      
        def onTabChange(self, tabIndex):
                self.tabIndex = tabIndex
        def anaResult(self):
                anaRange=self.setting.tabAll.DataText.anaRange.value()
                anaBaseline=self.setting.tabAll.DataText.anaBaseline.value()                
                anaResultText=''

                # self.ana_x, self.ana_y = fil2a.TexTFileto2ColumeArray('2023_08_17_16_45.txt', ",", self.loggername, 3)
                # self.act.run_index=1
                # self.accu_data=self.ana_y
                # self.x_data=self.ana_x
                if self.tabIndex == 0:
                        self.ana_data_x = self.x_data
                        self.ana_data_y = self.accu_data
                        if self.setting.tabAll.HVscan.gaussianFilterCheck.isChecked():
                                self.ana_data_y = self.gaussian_filter

                if self.tabIndex == 1:
                        self.ana_data_x = self.ana_x
                        self.ana_data_y = self.ana_y

                # print('tabIndex',self.tabIndex)

                # if(self.act.run_index != 0):
                for j in range(8):
                        v = getattr(self.setting.tabAll.DataText,f'v{j+1}').value()       
                        if v != 0:
                                try:
                                        min=np.where(self.ana_data_x>=v-anaRange)[0][0]
                                        max=np.where(self.ana_data_x>=v+anaRange)[0][0]
                                        if (len(np.where(self.ana_data_y[min:max+1]>anaBaseline)[0]))!= 0:                                                
                                                n = getattr(self.setting.tabAll.DataText,f'n{j+1}').text()
                                                anaResultText += n+'\n'
                                except:
                                        pass
                                                
                if anaResultText != '':
                        QMessageBox().about(self, "Result", anaResultText)                                
                else:
                        QMessageBox().about(self, "Result", 'None')                                
                     

        def anaResult1(self):                
                anaBaseline=self.setting.tabAll.DataText.anaBaseline.value()
                anaWidth=self.setting.tabAll.DataText.anaWidth.value()
                anaResultText=''    

                # self.ana_x, self.ana_y = fil2a.TexTFileto2ColumeArray('2023_08_17_16_45.txt', ",", self.loggername, 3)
                # self.act.run_index=1
                # self.accu_data=self.ana_y
                # self.x_data=self.ana_x                
                if self.tabIndex == 0:
                        self.ana_data_x = self.x_data
                        self.ana_data_y = self.accu_data
                        if self.setting.tabAll.HVscan.gaussianFilterCheck.isChecked():
                                self.ana_data_y = self.gaussian_filter

                if self.tabIndex == 1:
                        self.ana_data_x = self.ana_x
                        self.ana_data_y = self.ana_y

                # print('tabIndex',self.tabIndex)
                # if(self.act.run_index != 0):
                for j in range(8):
                        v = getattr(self.setting.tabAll.DataText,f'v{j+1}').value()                                
                        if v != 0:                                        
                                try:
                                        peaks , info = sp.signal.find_peaks(self.ana_data_y, height= anaBaseline , width = anaWidth)  
                                        
                                        left_index = int(info.get('left_ips')[0])
                                        right_index = int(info.get('right_ips')[0])
                                                        
                                        firstPeak_range = self.ana_data_y[left_index+1:right_index+1]

                                        if any(element > 18800 for element in firstPeak_range):
                                                peak_y_max=np.where(firstPeak_range>18800)                                                        
                                                firstPeak=int(sum(self.ana_data_x[peak_y_max[0][0]+left_index+1:peak_y_max[0][-1]+left_index+2])/len(peak_y_max[0]))
                                                
                                        else: 
                                                firstPeak = self.ana_data_x[peaks[0]]      

                                        print(firstPeak)

                                        dv=getattr(self.setting.tabAll.DataText,f'dv{j+1}').value()
                                        dvRange=getattr(self.setting.tabAll.DataText,f'dvRange{j+1}').value()

                                        min=np.where(self.ana_data_x>=firstPeak+dv)[0][0]
                                        max=np.where(self.ana_data_x>=firstPeak+dv+dvRange)[0][0]
                                        
                                        if (len(np.where(self.ana_data_y[min:max+1]>anaBaseline)[0]))!= 0:    
                                                n = getattr(self.setting.tabAll.DataText,f'n{j+1}').text()                                           
                                                anaResultText += n+'\n' 
                                except:
                                        pass

                if anaResultText != '':
                        QMessageBox().about(self, "Result", anaResultText)                                
                else:
                        QMessageBox().about(self, "Result", 'None') 
                               

                     


        def LoadPreset(self):
                self.setting.tabAll.HVscan.StartVoltage.setValue(int(self.scanParam.start))
                self.setting.tabAll.HVscan.VoltageStep.setValue(float(self.scanParam.step))
                self.setting.tabAll.HVscan.Loop.setValue(int(self.scanParam.loops))
                self.setting.tabAll.HVscan.Back.setValue(int(self.scanParam.scanBkWd))
                self.setting.tabAll.HVscan.offset.setValue(int(self.scanParam.offset))
                self.setting.tabAll.HVscan.Run_loop.setValue(int(self.scanParam.max_run_loops))
                self.setting.tabAll.HVscan.delay.setValue(int(self.scanParam.delay))
                self.setting.tabAll.HVscan.autoShowResult.setValue(int(self.scanParam.autoShowResult))
                self.setting.tabAll.HVscan.gaussianFilter.setValue(int(self.scanParam.gaussian_sigma))

                self.setting.tabAll.DCset.DC_Voltage1.setValue(int(self.scanParam.dc_fixed))
                self.setting.tabAll.DCset.DC_Voltage2.setValue(int(self.scanParam.dc_esi))
                self.setting.tabAll.Fan.Fan_Speed.setValue(int(self.scanParam.dc_fan))

                if (self.scanParam.adc_pority == -1):
                        self.setting.tabAll.DataSampling.poBtn2.setChecked(True)
                else:
                        self.setting.tabAll.DataSampling.poBtn1.setChecked(True)

                self.setting.tabAll.DataSampling.AVG_time.setValue(int(self.scanParam.avg_time))

                self.setting.tabAll.TicXic.xicMassCenter.setValue(int(self.scanParam.xic_center))
                self.setting.tabAll.TicXic.xicMassRange.setValue(float(self.scanParam.xic_delta))
                self.setting.tabAll.TicXic.xicThreshold.setValue(int(self.scanParam.ana_height))
                self.setting.tabAll.TicXic.xicWidth.setValue(int(self.scanParam.ana_width))

# start Unique Function Define 
        def ConnectRun(self):
                self.act.COM.cp = 0
                self.act.COM.find_com = False
                self.act.status = 1
                self.fanact.status = 1
                self.connectStatus = self.act.usbConnect()

                if self.connectStatus:
                        self.setting.tabAll.Signal_new.comport.SetConnectText(Qt.black,"Connection build", False)
                        self.SetAllDacZero()
                        self.setEnableButton4conn()
                else:
                        self.setting.tabAll.Signal_new.comport.SetConnectText(Qt.red,"Connect failed", True)

        def setEnableButton4conn(self):
                # self.top.comport.connectBtn.setEnabled(False)
                self.setEnableButton4stop()

        def SetAllDacZero(self):
                for i in range(1, 6):
                        self.act.setVoltage(i, 0)
                # self.setting.tabAll.DCset.fixed_label2.setText("0")
                self.setting.tabAll.DCset.esi_label2.setText("0")
                self.setting.tabAll.Fan.fanLabel2.setText("0")
                self.setting.tabAll.HVscan.text2.setText("0")
                self.act.Vdcout = 0
                self.act.Vscanout = 0

#DC Voltage and Fan Control
        # def setFixedVolt(self):
        #       self.scanParam.dc_fixed = self.setting.tabAll.DCset.DC_Voltage1.spin.value()
        #       self.setting.tabAll.DCset.fixed_label2.setText(str(self.scanParam.dc_fixed))
        #       self.act.setVoltage(4, self.scanParam.dc_fixed)
        #       self.LoadScanValue()
        #       self.scanParam.savePresetFile()

        def setESI(self):
                interLock = self.act.checkInterLock()
                if (interLock != 1):
                        self.showErrorMsg(True, interLock)
                        return
                self.scanParam.dc_esi = self.setting.tabAll.DCset.DC_Voltage2.value()
                self.setting.tabAll.DCset.esi_label2.setText(str(self.scanParam.dc_esi))
                self.act.setVoltage(ESI_CHANNEL, self.scanParam.dc_esi)
                self.LoadScanValue()
                self.scanParam.savePresetFile()

        def setFan(self):
                interLock = self.fanact.checkInterLock()
                if (interLock != 1):
                        self.showErrorMsg(True, interLock)
                        return
                self.scanParam.dc_fan = self.setting.tabAll.Fan.Fan_Speed.value()
                out = float(self.scanParam.dc_fan) / 1000.0
                #-----------
                print(out)
                out1=1
                #----------
                self.setting.tabAll.Fan.fanLabel2.setText(str(self.scanParam.dc_fan))

                N=(out-1)*20
                N=int(N)
                
                for i in range(N):
                        out1=out1+0.05
                        print(out1)
                        self.act.setVoltage(FAN_CHANNEL, out1)
                        time.sleep(0.3)
                
                
                self.LoadScanValue()
                self.scanParam.savePresetFile()
                if (out == 0):
                        self.fanact.fanFlag = False
                        self.updateFan(0)
                elif (self.fanact.fanFlag == False):
                        self.fanact.fanFlag = True
                        self.thread2.start()
                        self.thread2.setPriority(QThread.LowPriority)
                        # print("start 2")


        def setESIandFan(self):    
                
                #setFan
                interLock = self.fanact.checkInterLock()
                if (interLock != 1):
                        self.showErrorMsg(True, interLock)
                        return
                #setESI
                interLock = self.act.checkInterLock()
                if (interLock != 1):
                        self.showErrorMsg(True, interLock)
                        return


                #setFan
                self.scanParam.dc_fan = self.setting.tabAll.Fan.Fan_Speed.value()
                out = float(self.scanParam.dc_fan) / 1000.0
                #-----------    
                print(out)
                out1=1
                #----------
                self.setting.tabAll.Fan.fanLabel2.setText(str(self.scanParam.dc_fan))

                N=(out-1)*20
                N=int(N)
                
                for i in range(N):
                        out1=out1+0.05
                        print(out1)
                        self.act.setVoltage(FAN_CHANNEL, out1)
                        time.sleep(0.3)
                
                
                self.LoadScanValue()
                self.scanParam.savePresetFile()
                if (out == 0):
                        self.fanact.fanFlag = False
                        self.updateFan(0)
                elif (self.fanact.fanFlag == False):
                        self.fanact.fanFlag = True
                        self.thread2.start()
                        self.thread2.setPriority(QThread.LowPriority)
                        # print("start 2")


                #setESI
                self.scanParam.dc_esi = self.setting.tabAll.DCset.DC_Voltage2.value()
                self.setting.tabAll.DCset.esi_label2.setText(str(self.scanParam.dc_esi))
                self.act.setVoltage(ESI_CHANNEL, self.scanParam.dc_esi)
                # self.LoadScanValue()
                # self.scanParam.savePresetFile()
                



#       def resetBtn(self):
#               self.act.resetAlldata()

        def DCmodeBtn(self):
                interLock = self.act.checkInterLock()
                if (interLock != 1):
                        self.InterLockStatus = interLock # MUST write beofre show error box
                        self.showErrorMsg(True, interLock)
                        return
                self.scanFlag = False
                self.LoadDcMode()
                self.raw_path = ""
                self.setEnableButton4start()
                self.act.resetAlldata()
                self.setting.runIndex.setText("0")
                self.act.run_flag = True
                if self.fanact.fanFlag: # fix 2 Qthread writeLine will conflict
                        self.preFanFlag = True
                        self.fanact.fanFlag = False
                self.thread1.start()
                self.thread1.setPriority(QThread.HighPriority)
                # print("start 1")

        def ScanBtn(self):
                self.setESIandFan()

                time.sleep(0.3)

                interLock = self.act.checkInterLock()
                if (interLock != 1):
                        self.InterLockStatus = interLock # MUST write beofre show error box
                        self.showErrorMsg(True, interLock)
                        return
                self.scanFlag = True
                self.LoadScanMode()
                # if self.top.Signal.checkbox.isChecked():
                #self.raw_path = QFileDialog.getExistingDirectory(self,"Save Raw Data", "./")
                self.raw_path = ""
                # if self.raw_path == "":
                        # return 
                self.setEnableButton4start()
                self.act.resetAlldata()
                self.setting.tabAll.Signal_new.runIndex.setText("0")
                self.act.run_flag = True
                if self.fanact.fanFlag: # fix 2 Qthread writeLine will conflict
                        self.preFanFlag = True
                        self.fanact.fanFlag = False
                self.thread1.start()
                self.thread1.setPriority(QThread.HighPriority)
                # print("start 1")
                self.showAnaResult=True

        def LoadScanValue(self):
                self.scanParam.start = self.setting.tabAll.HVscan.StartVoltage.value()
                self.scanParam.step = self.setting.tabAll.HVscan.VoltageStep.value()
                self.scanParam.loops = self.setting.tabAll.HVscan.Loop.value()
                self.scanParam.scanBkWd = self.setting.tabAll.HVscan.Back.value()
                self.scanParam.offset = self.setting.tabAll.HVscan.offset.value()
                self.scanParam.max_run_loops = self.setting.tabAll.HVscan.Run_loop.value()
                self.scanParam.delay = self.setting.tabAll.HVscan.delay.value()
                self.scanParam.autoShowResult = self.setting.tabAll.HVscan.autoShowResult.value()
                self.scanParam.dc_fixed = self.setting.tabAll.DCset.DC_Voltage1.value()
                self.scanParam.xicMode = self.setting.tabAll.HVscan.checkTic.isChecked()
                self.scanParam.gaussian_sigma = self.setting.tabAll.HVscan.gaussianFilter.value()

                if self.setting.tabAll.DataSampling.poBtn2.isChecked():
                        self.scanParam.adc_pority = -1
                else:
                        self.scanParam.adc_pority = 1

                self.scanParam.avg_time = self.setting.tabAll.DataSampling.AVG_time.value()

                self.scanParam.xic_center = self.setting.tabAll.TicXic.xicMassCenter.value()
                self.scanParam.xic_delta = self.setting.tabAll.TicXic.xicMassRange.value()
                self.scanParam.ana_height = self.setting.tabAll.TicXic.xicThreshold.value()
                self.scanParam.ana_width = self.setting.tabAll.TicXic.xicWidth.value()

        def LoadDcMode(self):
                self.LoadScanValue()
                self.scanParam.savePresetFile()
                self.scanParam.step = 0
                self.scanParam.loops = 10000000
                self.scanParam.max_run_loops = 1

        def LoadScanMode(self):
                self.LoadScanValue()
                self.scanParam.savePresetFile()

        def setEnableButton4start(self):
                self.setting.tabAll.Signal_new.DCmode.setEnabled(False)
                self.setting.tabAll.Signal_new.startScan.setEnabled(False)
                if (self.act.status != 1): # USB error
                        self.setting.tabAll.Signal_new.stop.setEnabled(False)
                else:
                        self.setting.tabAll.Signal_new.stop.setEnabled(True)
                self.setting.tabAll.Signal_new.Signal.SaveDataBtn.setEnabled(False)
                # self.setting.tabAll.HVscan.reset.setEnabled(False)
                # self.setting.tabAll.DCset.V1_Btn.setEnabled(False)
                self.setting.tabAll.DCset.V2_Btn.setEnabled(False)
                self.setting.tabAll.Fan.FanBtn.setEnabled(False)
                #--------------------------------------------------
                self.setting.tabAll.Fan.esiFanBtn.setEnabled(False)
                #--------------------------------------------------
                self.setting.tabAll.Analysis.CurrBtn.setEnabled(True)

        def StopBtn(self):
                if self.scanFlag:
                        self.scanParam.max_run_loops = 0
                else:
                        self.scanParam.loops = 0
                self.act.run_flag = False

                #----------------------------------------------------
                self.SetAllDacZero()
                
     

        def SettingBtn(self):
                self.setting.showFullScreen()
       
                
                
        def onClosePress(self):
                self.StopBtn()
                self.close()

        def CloseThread(self):
                self.act.run_flag = False
                self.thread1.quit()
                self.thread1.wait()
                # print("quit 1")
                # if not self.scanFlag:
                #       self.act.resetAlldata()
                if (self.act.status != 1):      # USB error
                        self.setEnableButton4start()
                else:
                        self.setEnableButton4stop()
                        self.setting.tabAll.Signal_new.Signal.SaveDataBtn.setEnabled(True)
                # fix 2 Qthread writeLine will conflict
                if (self.preFanFlag):
                        self.fanact.fanFlag = True
                        self.thread2.start()
                        self.thread2.setPriority(QThread.LowPriority)
                        # print("start 2")

        def updateFan(self, freq):
                # print("updateFan")
                self.setting.tabAll.Fan.fanLabel2.setText(str(freq))
                # print("InterLockStatus = " + str(self.InterLockStatus))
                interLock = self.fanact.checkInterLock()
                # print("read interLock = " + str(interLock))

                if (interLock != 1) and (self.InterLockStatus == 1):
                        self.showErrorMsg(True, interLock)
                else:
                        self.InterLockStatus = interLock

        def CloseThread2(self):
                self.thread2.quit()
                self.thread2.wait()
                # print("quit 2")

        def setEnableButton4stop(self):
                self.setting.tabAll.Signal_new.DCmode.setEnabled(True)
                self.setting.tabAll.Signal_new.startScan.setEnabled(True)
                self.setting.tabAll.Signal_new.stop.setEnabled(False)
                self.setting.tabAll.HVscan.turnoff.setEnabled(True)
                # self.setting.tabAll.DCset.V1_Btn.setEnabled(True)
                self.setting.tabAll.DCset.V2_Btn.setEnabled(True)
                self.setting.tabAll.Fan.FanBtn.setEnabled(True)
                self.setting.tabAll.Fan.esiFanBtn.setEnabled(True)

        def UpdateAccuIndex(self, index, single_data):
                self.setting.tabAll.Signal_new.runIndex.setText(str(index))
                # if self.top.Signal.checkbox.isChecked() and self.scanFlag:

                if (self.raw_path != "" ) and self.scanFlag:
                        tempdata = np.array([self.x_data, single_data], np.float64)
                        tempdata = np.transpose(tempdata)
                        curr_time = datetime.datetime.now()
                        fileheader = self.setting.tabAll.Signal_new.FHedit.edit.text()+"\n"+str(curr_time)+"\n"+"dV(mV), Signal(mV)"
                        fname = self.raw_path+"/"+curr_time.strftime("%Y_%m_%d_%H_%M")+".txt"
                        #print(fname)
                        fil2a.list2DtoTextFile(fname,tempdata,",",self.loggername, fileheader)

        def updateText(self, vol, signal):
                volStr = str(vol) + " (V)"
                self.setting.tabAll.HVscan.text2.setText(volStr)
                self.setting.tabAll.Signal_new.Signal.text.setText(str("%3.1f" %signal))

                interLock = self.act.checkInterLock()
                if (interLock != 1):
                        self.showErrorMsg(True, interLock)

        # def PlotData(self, single_data, accu_data, x_data):
        def PlotData(self, single_data, accu_data, x_data, filter, filter_data):
                single_len = len(single_data)
                self.x_data = x_data
                self.accu_data = accu_data

                if (filter):
                        self.filter_data = filter_data
                else:
                        self.filter_data = None
                        
                #--------------------------------------------
                self.top.tabPlot.plot1.ax1.clear()
                #--------------------------------------------
              
                x1=self.scanParam.start-self.scanParam.dc_fixed
                self.x1=x1
                # print(x1)
                x2=x1+self.scanParam.loops
                self.x2=x2
                # print(x2)
                self.top.tabPlot.plot1.ax2.clear()
                self.top.tabPlot.plot1.ax2.set_yticks([110])
                self.top.tabPlot.plot1.ax2.set_xticks([0])  
                self.top.tabPlot.plot1.ax2.set(xlim=(x1,x2),ylim=(0,100))  

                if self.scanFlag:
                        if (self.act.run_index == 0):
                                self.top.tabPlot.plot1.ax1.clear()
                                self.top.tabPlot.plot1.toolbar.update()  

                        self.top.tabPlot.plot1.ax1.set_xlabel("dV1 (V)")                           
                        self.top.tabPlot.plot1.ax1.set(xlim=(x1,x2))     

                        path = './set/text.txt'
                        text=fil2a.setTextToArray(path)  
                        for j in range(8):
                                if (int(text[j][0]) != 0 ) and (str(text[j][4])!= ''):
                                        self.top.tabPlot.plot1.ax2.bar([int(text[j][0])],[100],width=self.r*2,alpha=.1,color=str(text[j][4]))   
                                        self.top.tabPlot.plot1.ax2.text(int(text[j][2]),int(text[j][3]),str(text[j][1]),fontsize=14,fontfamily='SimSun')  
                             
                else:
                        self.top.tabPlot.plot1.ax1.clear()
                        self.top.tabPlot.plot1.ax1.set_xlabel("index (V)")


                self.top.tabPlot.plot1.ax1.set_ylabel("Output Voltage (mV)",fontsize=10)

                #
                self.top.tabPlot.plot1.ax1.tick_params(axis='x', labelsize=10)
                self.top.tabPlot.plot1.ax1.tick_params(axis='y', labelsize=10)

                self.top.tabPlot.plot1.ax1.plot(x_data[0:single_len], single_data, color = "blue", linestyle = '-', label= "real-time")

                if self.setting.tabAll.HVscan.gaussianFilterCheck.isChecked():	                
                        gFilter=self.setting.tabAll.HVscan.gaussianFilter.value()
                        self.gaussian_filter = gaussian_filter1d(single_data, gFilter)  
                        self.top.tabPlot.plot1.ax1.plot(x_data[0:single_len], self.gaussian_filter, color = "orange", linestyle = '-', label= "gaussian filter")
              

                self.top.tabPlot.plot1.ax1.patch.set_alpha(0.1)

                
                if self.act.run_index == self.setting.tabAll.HVscan.autoShowResult.value() and self.showAnaResult:      
                        self.anaResult1()
                        self.showAnaResult=False

                if self.scanFlag and (self.act.run_index != 0):                        
                        #self.top.tabPlot.plot1.ax1.clear()
                        self.top.tabPlot.plot1.ax1.set_xlabel("dV (V)")
                        self.top.tabPlot.plot1.ax1.set_ylabel("Output Voltage (mV)")
                        self.top.tabPlot.plot1.ax1.plot(x_data, accu_data, color = "green", linestyle = '-', label ="accumulated")
                        self.top.tabPlot.plot1.ax1.legend()

                if (filter):
                        self.top.tabPlot.plot1.ax1.plot(x_data[0:single_len], filter_data, color = "orange", linestyle = '-', label ="filtered")
                        self.top.tabPlot.plot1.ax1.legend()

                self.top.tabPlot.plot1.figure.canvas.draw()
                self.top.tabPlot.plot1.figure.canvas.flush_events()

     
        def SaveAvgData(self):
                SaveFileName,_ = QFileDialog.getSaveFileName(self,"Save Analysis Data",READOUT_FILENAME,"Text Files (*.txt)")
                if (SaveFileName != ''):
                        curr_time = datetime.datetime.now()
                        fileheader = self.setting.tabAll.Signal_new.FHedit.edit.text()+"\n"+str(curr_time)+"\n"+"dV(mV), Signal(mV)"
                        tempdata = np.array([self.x_data, self.accu_data], np.float64)
                        tempdata = np.transpose(tempdata)
                        fil2a.list2DtoTextFile(SaveFileName,tempdata,",",self.loggername, fileheader)

#Data Analysis
        def LoadAnaData(self):
                fname,_ = QFileDialog.getOpenFileName(self,"Load Signal Data","","Text Files (*.txt)")
                if (fname != ''):
                        self.ana_x, self.ana_y = fil2a.TexTFileto2ColumeArray(fname, ",", self.loggername, 3)
                        self.DrawAnaPlot()
                self.setting.tabAll.Analysis.AnaBtn.setEnabled(True)
                self.setting.close()
                self.tabIndex=2

        def UseCurrData(self):
                self.ana_x = self.x_data
                self.ana_y = self.accu_data
                self.DrawAnaPlot()

        def DrawAnaPlot(self):
                self.top.tabPlot.plot3.ax.clear()
                #----------------------------------------------------------------------------------------------------------------------
                path = './set/text.txt'
                text=fil2a.setTextToArray(path)
                if len(self.ana_y) != 0 and np.max(self.ana_y)>=100:
                        text_y=np.max(self.ana_y)
                else:
                        text_y=100                        
                        self.top.tabPlot.plot3.ax.set(xlim=(50,200))
                
                for j in range(8):
                        if (int(text[j][0]) != 0 ) and (str(text[j][4])!= ''):
                                self.top.tabPlot.plot3.ax.bar([int(text[j][0])],text_y,width=self.r*2,alpha=.1,color=str(text[j][4]))   
                                self.top.tabPlot.plot3.ax.text(int(text[j][2]),text_y*int(text[j][3])/100+text_y/20,str(text[j][1]),fontsize=14,fontfamily='SimSun')  
                
                self.top.tabPlot.plot3.ax.set_xlabel("dV (V)")
                self.top.tabPlot.plot3.ax.set_ylabel("Voltage Output (mV)")
                self.top.tabPlot.plot3.ax.plot(self.ana_x, self.ana_y)        

                self.top.tabPlot.plot3.toolbar.update()        
                
                self.top.tabPlot.plot3.figure.canvas.draw()
                self.top.tabPlot.plot3.figure.canvas.flush_events()



        def FinkPeakBtn(self):
                th = self.setting.tabAll.Analysis.Threshold.spin.value()
                width = self.setting.tabAll.Analysis.Width.spin.value()
                self.setting.tabAll.Analysis.PeakInfo.clearInfo()
                self.analist = self.act.findPeak(self.ana_x, self.ana_y, th, width)
                self.DrawAnaPlot()
                self.setting.tabAll.Analysis.AnaBtn.setEnabled(True)

                for i in range (0, len(self.analist)):
                        self.top.tabPlot.plot3.ax.axvline(x=self.analist[i][0], color='k')
                        self.top.tabPlot.plot3.ax.text(self.analist[i][0], self.analist[i][1], str("peak%d" %(i+1)), fontsize=12)
                        if i ==0:
                                self.setting.tabAll.Analysis.PeakInfo.peak1_pos.setText(str(self.analist[i][0]))
                                self.setting.tabAll.Analysis.PeakInfo.peak1_area.setText(str(self.analist[i][3]))
                        elif i == 1:
                                self.setting.tabAll.Analysis.PeakInfo.peak2_pos.setText(str(self.analist[i][0]))
                                self.setting.tabAll.Analysis.PeakInfo.peak2_area.setText(str(self.analist[i][3]))
                        elif i ==2:
                                self.setting.tabAll.Analysis.PeakInfo.peak3_pos.setText(str(self.analist[i][0]))
                                self.setting.tabAll.Analysis.PeakInfo.peak3_area.setText(str(self.analist[i][3]))
                        elif i ==3:
                                self.setting.tabAll.Analysis.PeakInfo.peak4_pos.setText(str(self.analist[i][0]))
                                self.setting.tabAll.Analysis.PeakInfo.peak4_area.setText(str(self.analist[i][3]))
                        elif i ==4:
                                self.setting.tabAll.Analysis.PeakInfo.peak5_pos.setText(str(self.analist[i][0]))
                                self.setting.tabAll.Analysis.PeakInfo.peak5_area.setText(str(self.analist[i][3]))
                        elif i== 5:
                                self.setting.tabAll.Analysis.PeakInfo.peak6_pos.setText(str(self.analist[i][0]))
                                self.setting.tabAll.Analysis.PeakInfo.peak6_area.setText(str(self.analist[i][3]))

                self.top.tabPlot.plot3.figure.canvas.draw()
                self.top.tabPlot.plot3.figure.canvas.flush_events()
                self.setting.tabAll.Analysis.AnaBtn.setEnabled(False)
                self.setting.tabAll.Analysis.SaveBtn.setEnabled(True)
                

        def SaveAnaData(self):
                SaveFileName,_ = QFileDialog.getSaveFileName(self,"Save Analysis Data",ANALYSIS_FILENAME,"Text Files (*.txt)")
                if (SaveFileName != ''):
                        curr_time = datetime.datetime.now()
                        fileheader = self.setting.tabAll.Signal_new.FHedit.edit.text()+"\n"+"dV(V) , peak_height (V), peak_width(V), peak_area"
                        fil2a.list2DtoTextFile(SaveFileName, self.analist,",",self.loggername, fileheader)
                        self.setting.tabAll.Analysis.SaveBtn.setEnabled(False)
        
        def ShowThreshold(self):
                value = float(self.setting.tabAll.Analysis.Threshold.spin.value())
                self.top.tabPlot.plot3.ax.clear()
                self.top.tabPlot.plot3.ax.set_xlabel("dV (V)")
                self.top.tabPlot.plot3.ax.set_ylabel("Voltage Output (V)")
                self.top.tabPlot.plot3.ax.plot(self.ana_x, self.ana_y)
                self.top.tabPlot.plot3.ax.axhline(y=value, color='r')
                self.top.tabPlot.plot3.figure.canvas.draw()
                self.top.tabPlot.plot3.figure.canvas.flush_events()

                self.setting.tabAll.Analysis.AnaBtn.setEnabled(True)

        def NoiseChange(self):
                self.setting.tabAll.Analysis.AnaBtn.setEnabled(True)

        def aboutBox(self):
                versionBox = QMessageBox()
                versionBox.about(self, "Version", VERSION_TEXT)

        def errorBox(self, msg):
                # print("show error box")
                msgBox = QMessageBox()
                msgBox.about(self, "Message", msg)

        def showErrorMsg(self, interLock, status):
                # statue != 1 will show error
                self.StopBtn()
                self.fanact.fanFlag = False
                self.InterLockStatus = status # MUST write beofre show error box
                if (interLock):
                        msg = "Inter Lock Error(" + str(status) + ") !!\nPlease Close it."
                        self.errorBox(msg)
                elif (status != 1):
                        self.setting.comport.SetConnectText(Qt.red,"Connect failed", True)
                        if (status == 3):
                                msg = "Read Fan Error !!"
                        elif (status == 2):
                                msg = "Read ADC Error !!"
                        else:
                                msg = "USB Error !!\nPlease reconnect."
                        self.errorBox(msg)

        def closeEvent(self, event):
                # print("window close")
                self.StopBtn()
                self.fanact.fanFlag = False
                self.SetAllDacZero()
                
                self.TextBtnData()                

                self.LoadScanValue()
                self.scanParam.savePresetFile()
                
                

        #------------------------
        def TextBtnData(self):
                # print(self.setting.tabAll.DataText.v1.text())

                path = './set/text.txt'                
                text_list=[]
                
                wtf=self.setting.tabAll.DataText

                for i in range(8):
                        v = getattr(wtf, f'v{i+1}').text()
                        n = getattr(wtf, f'n{i+1}').text()
                        x = getattr(wtf, f'x{i+1}').text()
                        y = getattr(wtf, f'y{i+1}').text()
                        c = getattr(wtf, f'c{i+1}').currentText()
                        dv = getattr(wtf, f'dv{i+1}').text()
                        dvRange = getattr(wtf, f'dvRange{i+1}').text()
                        text_list.append(v+','+n+','+x+','+y+','+c+','+dv+','+dvRange)  

                text_list.append(wtf.anaRange.text())
                text_list.append(wtf.anaBaseline.text())
                text_list.append(wtf.anaWidth.text())


                with open(path,'w',encoding="utf-8") as file:
                        for item in text_list:
                                file.write(str(item)+'\n')



if __name__ == '__main__':
        app = QApplication(sys.argv)
        main = mainWindow()
        main.showFullScreen()
        os._exit(app.exec_())
