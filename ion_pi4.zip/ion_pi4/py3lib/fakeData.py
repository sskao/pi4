import numpy as np 
import matplotlib.pyplot as plt 
#import FileToArray as fil2a

class QSS005MSData():
	def __init__(self, pts):
		self.pts = pts
		self.data = np.zeros(pts)

	def genRandDefine(self, numPeak, maxAmp):
		define = []
		for i in range(numPeak):
			pos = int(np.random.rand()*float(self.pts))
			amp = float(maxAmp)*np.random.rand()
			define.append([pos, amp])
		return define

	def genGaussianPeak(self, define, maxWidth):
		for i in range(len(define)):
			pos= define[i][0]
			amp = define[i][1]
			width = maxWidth*np.random.rand()*2.3548
			for j in range(self.pts):
				self.data[j] = self.data[j] + amp*np.exp(-(j-pos)**2/(2*width*maxWidth))
	def clearData(self):
		self.data = np.zeros(self.pts)

	def genPeak(self, define, width):
		for i in range(len(define)):
			pos = define[i][0]
			amp = define[i][1]
			for j in range(width):
				if j == 0:
					self.data[pos] = self.data[pos]+ amp
				else:
					if pos+j < self.pts:
						self.data[pos+j] = self.data[pos]+ amp/(j+0.5)
					if pos-j >=0:
						self.data[pos-j] = self.data[pos-j] + amp/(j+0.5)

	def genNoise(self, noiseAmp):
		self.data = self.data + np.random.rand(self.pts)*noiseAmp 

	def genPCR(self, timeconstant, xoffset, amp):
		self.xdata = np.linspace(0, 10, self.pts)
		self.data = amp/(np.exp(-(self.xdata-xoffset)/timeconstant)+1)

if __name__ == '__main__':
	number = 200
	fakeD = QSS005MSData(number)
	#define = fakeD.genRandDefine(5, 6)
	#fakeD.genPeak(define, 4)
	#fakeD.genNoise(1)
	#xdata = np.linspace(1, number, number)
	fakeD.genPCR(0.1,6, 300)
	fakeD.genNoise(100)
	xdata = np.empty(0)
	xdata = np.append(fakeD.xdata,fakeD.data)
	xdata= xdata.reshape(2,number)
	xdata= np.transpose(xdata)
	#print(xdata)

	#fil2a.list2DtoTextFile("ionMdata.txt", xdata,",", "test","\n\n\n")

	plt.plot(fakeD.xdata,fakeD.data)
	plt.show()

