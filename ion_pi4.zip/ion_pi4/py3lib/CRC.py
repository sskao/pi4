def CRC_16(data, divider):
	reg = 0xFFFF
	length = len(data)
	for i in range(0, length):
		reg = reg ^ data[i]
		for j in range(0, 8):
			if reg & 0x01 ==1:
				reg = (reg >>1) ^ divider
			else:
				reg = reg >> 1

	reg_H = reg >> 8
	reg_L = reg & 0x00FF
	data.append(reg_L)
	data.append(reg_H)
	return data
def InvertUnit(data, bit8):
	out = 0
	if bit8:
		order = 8 
	else:
		order = 16
	for i in range(order):
		if data & (1 << i):
			out |= (1 << (order-1-i))
	return out

def CRC_16_MODBUS(data):
	CRCin = 0xFFFF
	CPoly = 0x8005
	Char = 0 
	length = len(data)
	for i in range(length):
		Char = data[i]
		Char = InvertUnit(Char, True)
		CRCin ^= (Char << 8)
		for j in range(8):
			if CRCin & 0x8000 :
				CRCin = (CRCin << 1)^ CPoly
			else:
				CRCin =(CRCin << 1)
	CRCin = InvertUnit(CRCin, False)
	data = bytearray(data)
	data.append(CRCin&0xFF)
	data.append((CRCin>>8)&0xFF)

	return data


def CRC_8(data, divider):
	reg = 0xFF
	length = len(data)
	for i in range(0, length):
		reg = reg ^ data[i]
		for j in range(0, 8):
			if reg & 0x01 ==1:
				reg = (reg >>1) ^ divider
			else:
				reg = reg >> 1
	return reg

if __name__ == '__main__':
	data = [0x69, 0xAA, 0x00, 0x01, 0x00,0x00]
	out = CRC_16_MODBUS(data)


