from PyQt5.QtCore import *
from PyQt5.QtWidgets import *

def unsignedToSigned(usInput, maxbit):
	mask = 2**(maxbit)-1
	signedMax = 2**(maxbit -1)-1
	if usInput > signedMax:
		usInput = ((~(usInput-1))&mask)
		usInput = usInput*(-1)
	return usInput

def signedToUnsigned(signedInput, maxbit):
	maxValue = 2**maxbit -1
	if signedInput < 0:
		out = maxValue + 1 + signedInput
	else:
		out = signedInput
	return out

def is_number(s):
    try:
        int(s)
        return True
    except ValueError:
        pass
 
    try:
        float(s)
        return True
    except ValueError:
        pass
 
    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except (TypeError, ValueError):
        pass
 
    return False

def tableLockItem(value):
	item = QTableWidgetItem()
	# execute the line below to every item you need locked
	item.setFlags(Qt.ItemIsEnabled|Qt.ItemIsSelectable)
	value_str = str(value)
	item.setText(value_str)
	return item

def shortPathText(path_text, max_num):
	half_text_num = int(max_num/2-2)
	text1 = path_text[:half_text_num]
	text2 = path_text[-half_text_num:]
	short_text = text1 + "...." + text2
	return short_text

def getPathFileName(path, fileType): # fileType = ".mtd" or ".seq"
	subline = path.rstrip(fileType)
	outlist = subline.split('/')
	# print(outlist)
	len_out = len(outlist)
	# print(len_out)
	return outlist[len_out-1]


if __name__ == '__main__':
	unsignedToSigned(255, 8)
