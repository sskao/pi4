from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
import pyqtgraph as pg 

PLOT_FONTSIZE = 12
PLOT_FONTSIZE_S = 10
black_pen = pg.mkPen(QColor(0, 0, 0), width = 2)

class onePlot(pg.GraphicsLayoutWidget):
	def __init__(self, *args, **kargs):
		super().__init__(*args, **kargs)
		# self.setBackground("w")
		color = (173, 216, 230)
		self.setBackground(color)
		self.plot = self.addPlot(row = 0, col = 0)
		self.plot.getViewBox().setBackgroundColor("w")
		yaxis = pg.AxisItem('left', pen=black_pen, textPen=black_pen)
		xaxis = pg.AxisItem('bottom', pen=black_pen, textPen=black_pen)
		self.plot.setAxisItems(axisItems = {'left':yaxis,'bottom':xaxis} )

class focusDoubleSpin(QDoubleSpinBox):
	focusIn = pyqtSignal()

	def focusInEvent(self, event):
     	# print("focus-in")
		# self.setStyleSheet("background-color: yellow; color: red;")
		super().focusInEvent(event)
		self.focusIn.emit()

	def focusOutEvent(self, event):
		# print("focus-out")
		# self.setStyleSheet("background-color: white; color: black;")
		super().focusOutEvent(event)


class focusSpin(QSpinBox):
	focusIn = pyqtSignal()

	def focusInEvent(self, event):
		# print("focus-in")
		# self.setStyleSheet("background-color: yellow; color: red;")
		super().focusInEvent(event)
		self.focusIn.emit()

	def focusOutEvent(self, event):
		# print("focus-out")
		# self.setStyleSheet("background-color: white; color: black;")
		super().focusOutEvent(event)


class spinBlock(QGroupBox):
	def __init__(self, title, minValue, maxValue, double = False, step = 1, Decimals = 2, parent=None):
		super(spinBlock, self).__init__(parent)
		if (double):
			# self.spin = QDoubleSpinBox()
			self.spin = focusDoubleSpin()
			self.spin.setDecimals(Decimals)
		else:
			# self.spin = QSpinBox()
			self.spin = focusSpin()

		self.spin.setRange(minValue, maxValue)
		self.spin.setSingleStep(step)
		self.setTitle(title)

		layout = QHBoxLayout() 
		layout.addWidget(self.spin)
		self.setLayout(layout)


class checkSpinBlock(QGroupBox):
	def __init__(self, title, minValue, maxValue, double = False, step = 1, Decimals = 2, parent=None):
		super(checkSpinBlock, self).__init__(parent)
		if (double):
			self.check = QCheckBox()
			# self.spin = QDoubleSpinBox()
			self.spin = focusDoubleSpin()
			self.spin.setDecimals(Decimals)
		else:
			# self.spin = QSpinBox()
			self.spin = focusSpin()

		self.spin.setRange(minValue, maxValue)
		self.spin.setSingleStep(step)
		self.setTitle(title)

		layout = QGridLayout() 
		layout.addWidget(self.check, 0, 0, 1, 1)     
		layout.addWidget(self.spin, 0, 1, 1, 5)
		self.setLayout(layout)

class spinLabelBlock(QGroupBox):
	def __init__(self, title, labelname, labelvalue, minValue, maxValue, double = False, step = 1, Decimals = 2, parent=None):
		super(spinLabelBlock, self).__init__(parent)
		if double :
			self.spin = QDoubleSpinBox()
			self.spin.setDecimals(Decimals)
		else:
			self.spin = QSpinBox()

		self.spin.setRange(minValue, maxValue)
		self.spin.setSingleStep(step)
		self.labelname = QLabel(labelname)
		self.labelvalue = QLabel(labelvalue)
		self.setTitle(title)

		layout = QHBoxLayout()
		layout.addWidget(self.spin)
		layout.addWidget(self.labelname)
		layout.addWidget(self.labelvalue)
		self.setLayout(layout)


class checkEditBlock(QWidget):
	def __init__(self, name, min, max, parent=None):
		super(checkEditBlock, self).__init__(parent)
		self.name = name
		self.check = QCheckBox(name)
		self.value = QLineEdit()
		self.value.setValidator(QDoubleValidator(min, max, 4))

		layout = QHBoxLayout()
		layout.addWidget(self.check)
		layout.addWidget(self.value)
		self.setLayout(layout)


class editBlock(QGroupBox):
	def __init__(self, title, parent=None):
		super(editBlock, self).__init__(parent)
		self.edit = QLineEdit()
		self.setTitle(title)

		layout = QHBoxLayout() 
		layout.addWidget(self.edit)     
		self.setLayout(layout)


class myLineEdit(QLineEdit):
	signal = pyqtSignal(str)
	def __init__(self,parent):
		super(myLineEdit, self).__init__(parent)
		self.textChanged.connect(self.handleTextChanged)

	def handleTextChanged(self):
		self.signal.emit(self.text())


class myEditBlock(QGroupBox):
	def __init__(self, title, parent=None):
		super(myEditBlock, self).__init__(parent)
		self.edit = myLineEdit(self)
		self.setTitle(title)

		layout = QHBoxLayout() 
		layout.addWidget(self.edit)     
		self.setLayout(layout)


class labelBlock(QGroupBox):
	def __init__(self, title, setColor=False, bg_color=Qt.white, fg_color=Qt.black, parent=None):
		super(labelBlock, self).__init__(parent)
		self.text = QLabel()
		self.setTitle(title)

		if (setColor):
			pe = QPalette()
			pe.setColor(QPalette.WindowText, fg_color)
			self.text.setAutoFillBackground(True)
			pe.setColor(QPalette.Window, bg_color)
			#pe.setColor(QPalette.Background,Qt.black)
			self.text.setPalette(pe)
			self.text.setAlignment(Qt.AlignCenter)
			# self.text.setFont(QFont("", 14, QFont.bold))
			self.text.setFont(QFont("", 14))

		layout = QHBoxLayout() 
		layout.addWidget(self.text)     
		self.setLayout(layout)


class comboBlock(QGroupBox):
	def __init__(self, title, comboList, showGroupTitle = False, parent = None):
		super(comboBlock,self).__init__(parent)
		if (showGroupTitle):
			self.setTitle(title)
		else:
			self.text = QLabel(title)
		self.comboList = comboList
		self.combo = QComboBox()
		self.combo.addItems(comboList)
		self.title = title

	def layoutV(self):
		layout = QVBoxLayout()
		layout.addWidget(self.text)
		layout.addWidget(self.combo)
		self.setLayout(layout)

	def layoutH(self):
		layout = QHBoxLayout()
		layout.addWidget(self.text)
		layout.addWidget(self.combo)
		self.setLayout(layout)
		
	def layoutG(self):
		layout = QHBoxLayout()
		layout.addWidget(self.combo)
		self.setLayout(layout)     


class ComConnectBlock(QGroupBox):
	def __init__(self, name, paraent = None):
		super(ComConnectBlock,self).__init__(paraent)
		self.setTitle(name)
		self.combo = QComboBox()
		self.btn = QPushButton("Connect")
		self.status = QLabel()
		self.status.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
		self.SetConnectText(Qt.red, "Connect first !", True)
		self.layout()

	def layout(self):   
		layout = QGridLayout()
		layout.addWidget(self.btn, 0, 0, 2, 2)
		layout.addWidget(self.combo, 2, 0, 1, 2)
		layout.addWidget(self.status, 3, 0, 1, 2)
		self.setLayout(layout)

	def SetConnectText(self, color, text, flag):
		pe = QPalette()
		pe.setColor(QPalette.WindowText, color)
		self.status.setPalette(pe)
		self.status.setText(text)
		self.status.show()
		self.btn.setEnabled(flag)


class IPconnectBlock():
	def __init__(self, name):
		self.groupBox = QGroupBox(name)
		self.IP = QLineEdit()
		self.status = QLabel()
		self.status.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
		self.btn = QPushButton("Connect")
		self.SetConnectText(Qt.red, "Connect first !", True)

	def layout1(self):   
		layout = QVBoxLayout()
		layout.addWidget(self.IP)
		layout.addWidget(self.btn)
		layout.addWidget(self.status)
		self.groupBox.setLayout(layout)
		self.groupBox.show()
		return self.groupBox

	def SetConnectText(self, color, text, flag):
		pe = QPalette()
		pe.setColor(QPalette.WindowText, color)
		self.status.setPalette(pe)
		self.status.setText(text)
		self.status.show()
		self.btn.setEnabled(flag)

	def layout2(self):   
		layout = QGridLayout()
		layout.addWidget(self.IP, 0, 0, 1, 1)
		layout.addWidget(self.btn, 0, 1, 1, 1)
		layout.addWidget(self.status, 1, 0, 1, 2)
		self.groupBox.setLayout(layout)
		self.groupBox.show()
		return self.groupBox


class Folder_TreeView(QWidget):
	def __init__(self, path, parent=None):
		super(Folder_TreeView, self).__init__(parent)
		self.treeview = QTreeView()
		# self.listview = QListView()

		# useless for hidden column
		# self.treeview.setColumnHidden(1, True)
		# self.treeview.setColumnHidden(2, True)
		# self.treeview.setColumnHidden(3, True)

		# useless for hidden column
		# self.treeview.hideColumn(1)
		# self.treeview.hideColumn(2)
		# self.treeview.hideColumn(3)

		# useless for hidden column
		# self.treeview.header().hideSection(1)
		# self.treeview.header().hideSection(2)
		# self.treeview.header().hideSection(3)

		# path = QDir.rootPath()

		self.dirModel = QFileSystemModel()
		self.dirModel.setRootPath(QDir.rootPath())
		self.dirModel.setFilter(QDir.NoDotAndDotDot | QDir.AllDirs | QDir.Files)

		# self.fileModel = QFileSystemModel()
		# self.fileModel.setFilter(QDir.NoDotAndDotDot | QDir.Files)

		self.treeview.setModel(self.dirModel)
		# self.listview.setModel(self.fileModel)

		self.treeview.setRootIndex(self.dirModel.index(path))
		# self.listview.setRootIndex(self.fileModel.index(path))

		# self.treeview.clicked.connect(self.on_clicked)

		hlay = QHBoxLayout(self)
		hlay.addWidget(self.treeview)
		# hlay.addWidget(self.listview)
		self.setLayout(hlay)
		self.show()


class folderTree(QWidget):
	def __init__(self, path, onlyfile = False):
		super().__init__()
		self.initUI(path, onlyfile)

	def tree_cilcked(self, Qmodelidx):
		# print(self.model.filePath(Qmodelidx))
		# print(self.model.fileName(Qmodelidx))
		# print(self.model.fileInfo(Qmodelidx))
		self.current_path = self.model.filePath(Qmodelidx)
		# print("1 " + self.current_path)

	def initUI(self, path, onlyfile):
		# 這裡得到目錄結構
		self.model = QFileSystemModel()
		if (onlyfile):
			self.model.setFilter(QDir.NoDotAndDotDot | QDir.Files)
		else:
			self.model.setFilter(QDir.NoDot | QDir.AllDirs | QDir.Files)
		self.model.setRootPath(path)
		# 這裡過濾，只顯示 py 檔案
		# mf = self.model.setNameFilters(['*.py'])
		# self.model.setNameFilterDisables(False)
		# 這裡做展示
		self.tree = QTreeView()
		self.tree.setModel(self.model)
		self.tree.setRootIndex(self.model.index(path))
		# self.tree.doubleClicked.connect(self.tree_cilcked)
		self.tree.clicked.connect(self.tree_cilcked)
		# 這裡隱藏了目錄資訊展示
		for i in [1,2,3]:
			self.tree.setColumnHidden(i, True)
		# 縮排
		self.tree.setIndentation(10)
		# self.tree.resize(640, 480)
		windowLayout = QVBoxLayout()
		windowLayout.addWidget(self.tree)
		self.setLayout(windowLayout)
		self.show()

class QHLine(QFrame):
    def __init__(self):
        super(QHLine, self).__init__()
        self.setFrameShape(QFrame.HLine)
        self.setFrameShadow(QFrame.Sunken)


class QVLine(QFrame):
    def __init__(self):
        super(QVLine, self).__init__()
        self.setFrameShape(QFrame.VLine)
        self.setFrameShadow(QFrame.Sunken)
