import serial
import serial.tools.list_ports
import platform
import logging
import py3lib.QuLogger

ft232_name_in = "0403:6001"
arduino_name_in = "2341:0043"
#ft232_name_in_mac = "0403:6001"
#ft232_name_in_win = "VID_0403+PID_6001"
#ft232_name_in_win = "USB VID:PID=2341:0043"	#Arduino Uno

class checkCom:
	def __init__(self, loggername):
		self.logger = logging.getLogger(loggername)

	def listAllCom(self):
		portlist = serial.tools.list_ports.comports()
		os = platform.system()
		# print(os)
		multiCom = []

		for a in portlist:
			# print(a[2])
			multiCom.append(a[0])
			# print(multiCom)

		if (len(multiCom) == 0):
			self.logger.error("Can't Find the COM Port")

		return multiCom


class FT232:
	def __init__(self, loggername):
		self.cp = 0
		self.port = serial.Serial()
		self.find_com = False
		self.logger = logging.getLogger(loggername)
		#self.port = self.comDetect()
		#if (self.find_com == True):
		#	self.port.flush()
	
	def connect(self, baudrate = 115200, timeout = 1):
		self.baudrate = baudrate
		self.timeout = timeout
		self.find_com = self.checkCom()
		self.port = self.comDetect()
		if (self.find_com == True):
			self.port.flush()

		return self.find_com

	def portConnect(self, portid, baudrate = 115200, timeout = 1):
		self.baudrate = baudrate
		self.timeout = timeout
		self.find_com = self.checkPortCom(portid)
		self.port = self.comDetect()
		if (self.find_com == True):
			self.port.flush()

		return self.find_com

	def comPortConnect(self, cp, baudrate = 115200, timeout = 1):
		self.baudrate = baudrate
		self.timeout = timeout
		# self.find_com = self.checkCom()
		print("comPortConnect = " + str(cp) )
		self.port = self.comPortDetect(cp)
		if (self.find_com == True):
			self.port.flush()

		return self.find_com

	def checkPortCom(self, portid):
		find_com = False
		portlist = serial.tools.list_ports.comports()
		os = platform.system()
		for a in portlist:
			if portid in a[2]:
				self.cp = a[0]

		if self.cp != 0:
			find_com = True
		else:
			self.logger.error("Can't Find the COM Port")

		return find_com

	def checkCom(self):
		find_com = False
		portlist = serial.tools.list_ports.comports()
		os = platform.system()
		#print(os)
		for a in portlist:
			#print(a[2])
			if (ft232_name_in in a[2]) or (arduino_name_in in a[2]):
				self.cp = a[0]
		#print( "cp = " + str(self.cp) )
		if self.cp != 0:
			find_com = True
		else:
			self.logger.error("Can't Find the COM Port")

		return find_com

	def comDetect(self):
		ser = serial.Serial()
		if (self.find_com == True):
			ser = serial.Serial(self.cp)
			ser.baudrate = self.baudrate
			ser.timeout = self.timeout

		return ser

	def comPortDetect(self, cp):
		print("comPortDetect = " + str(cp) )
		ser = serial.Serial(cp)
		ser.baudrate = self.baudrate
		ser.timeout = self.timeout

		return ser

	def writeBinary(self, data):
		#print("in")
		data_list = list([data])
		#data_list.append('\n')
		self.port.write(data_list)
		self.logger.debug("write hex data="+str(data_list))

	def writeList(self, datalist):
		self.port.write(datalist) 
		self.logger.debug("writeList="+str(datalist))

	def reset_InputBuffer(self):
		self.port.reset_input_buffer()

	def getInWaitingLength(self):
		try:
			temp = self.port.inWaiting()
		except:
			self.logger.error("USB inWaiting Error")
			return -1
		else:
			return temp

	def readBinary(self):
		#print("out")
		try:
			temp = self.port.read()
		except:
			self.logger.error("readBinary failed")
			return "ERROR"
		else:
			if len(temp) > 0:
				data = ord(temp)
				self.logger.debug("read hex data="+str(data))
			else:
				data = temp

			self.logger.debug("read hex data failed")
			return data

	def readBytes(self, number):
		try:
			temp = self.port.read(number)
		except:
			self.logger.error("read bytes error")
			return "ERROR"
		else:
			return temp


	def writeLine(self, data, addR = False):
		# print("writeLine")
		if (addR == True):
			data_list = data + '\r\n'
		else:
			data_list = data + '\n'

		try:
			self.port.write(data_list.encode())
		except:
			self.logger.error("writeLine failed")
			status = False
		else:
			self.logger.debug(data_list)
			status = True
		# print(status)
		return status


	def readLine(self):
		# print("readLine")
		try:
			data = self.port.readline().decode()
		except:
			self.logger.error("readLine failed")
			print("ERROR")
			return "ERROR"
		else:
			return data


	def readLineF(self):
		self.port.flushInput()
		try:
			data = self.port.readline().decode()
		except:
			self.logger.error("readLine failed")
			return "ERROR"
		else:
			return data

	# pahse out module, avoid to use it in new project #### 2020,12,30
	def readBinaryMust(self, timeoutloop = 10):
		run = True
		loop = 1
		while(run):
			try:
				temp = self.port.read()
			except:
				self.logger.error("readBinaryMust failed")
				return "ERROR"
			else:
				if len(temp) > 0:
					data = ord(temp)
					self.logger.debug("read hex data =" +str(data))
					run = False
					return data
				loop = loop+1
				if (loop == timeoutloop):
					run = False
					self.logger.debug("read data timeout in readBinaryMust")	
	

class GeneralCOM:
	def __init__(self, loggername):
		self.port = serial.Serial()
		self.logger = logging.getLogger(loggername)
	
	def checkPortId(self, portid):
		find_com = False
		portname = None
		portlist = serial.tools.list_ports.comports()
		for a in portlist:
			if portid in a[2]:
				find_com = True
				portname = a[0]
		return find_com, portname

	def isOpen(self):
		return self.port.is_open

	def connectByName(self, portName, parity = "N", baudrate = 115200, timeout = 1):
		try:
			self.port = serial.Serial(portName)
		except:
			return -1
		self.port.baudrate = baudrate
		self.port.timeout = timeout
		self.port.parity = parity
		#status = self.port_isopen
		return 0
	
	def writeList(self, data_list):
		self.port.write(data_list)

	def writeLine(self, data, addR = False):
		if addR:
			data_list = data +'\r\n'
		else:
			data_list = data +'\n'
		try:
			self.port.write(data_list.encode())
		except:
			return 0
		else:
			return len(data_list)

	def resetInputBuffer(self):
		self.port.reset_input_buffer()

	def getInWaitingLength(self):
		try:
			temp = self.port.inWaiting()
		except:
			return -1
		else:
			return temp

	def readBinary(self, readbytes = 0):
		try:
			if readbytes:
				temp = self.port.read(readbytes)
			else:
				temp = self.port.read()
		except:
			return "ERROR"
		else:
			return temp
				

	def readLine(self):
		try:
			data = self.port.readline.decode()
		except:
			return "ERROR"
		else:
			return data

	def readBinaryCounts(self):
		temp =[]
		try:
			temp = self.port.read()
		except:
			pass
		
		length = len(temp)
		if length > 0:
			data = ord(temp)
		else:
			data = temp
		return length, data

	def close(self):
		self.port.close()


